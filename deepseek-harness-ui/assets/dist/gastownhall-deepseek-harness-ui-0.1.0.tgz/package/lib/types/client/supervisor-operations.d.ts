import type { CityOperationDescriptor, CityOperationPort } from './feed/index.js';
import { type SessionSummary } from './api.js';
export type SubmitIntent = 'default' | 'follow_up' | 'interrupt_now';
export type SessionControl = 'stop' | 'kill' | 'suspend' | 'close' | 'wake';
export declare class SupervisorRequestError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
export declare class SupervisorOutcomeUnknownError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
export declare function allowedSessionControls(state: string, activity?: string): readonly SessionControl[];
export interface SupervisorOperationsConfig {
    connectionId: string;
    cityName: string;
    fetch?: typeof globalThis.fetch;
}
export interface SupervisorOperations {
    submitSession(sessionId: string, message: string, intent?: SubmitIntent): Promise<CityOperationDescriptor>;
    createAgentSession(agentName: string, message: string): Promise<CityOperationDescriptor>;
    controlSession(sessionId: string, control: SessionControl): Promise<void>;
    fetchSession(sessionId: string): Promise<SessionSummary>;
    renameSession(sessionId: string, title: string): Promise<SessionSummary>;
    setPermissionMode(sessionId: string, permissionMode: string): Promise<SessionSummary>;
    cityOperationPort: CityOperationPort;
}
export declare function createSupervisorOperations(config: SupervisorOperationsConfig): SupervisorOperations;
//# sourceMappingURL=supervisor-operations.d.ts.map