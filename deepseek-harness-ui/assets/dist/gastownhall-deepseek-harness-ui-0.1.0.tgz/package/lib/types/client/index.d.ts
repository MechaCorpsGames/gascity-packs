import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { createSupervisorFeedPort, type SupervisorFeedPortConfig } from './supervisor-feed-port.js';
export { allowedSessionControls, createSupervisorOperations, type SubmitIntent, type SupervisorOperationsConfig, } from './supervisor-operations.js';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map