export type StructuredMessageStatus = "unknown" | "partial" | "final" | "superseded";
export type StructuredResetReason = "resume_invalid" | "stream_changed" | "cursor_invalidated" | "history_rewritten";
export interface StructuredMessage {
    readonly id: string;
    readonly role: string;
    readonly status: StructuredMessageStatus;
    readonly blocks?: readonly Readonly<Record<string, unknown>>[];
}
export interface TranscriptBootstrap {
    readonly sessionId: string;
    readonly transcriptStreamId: string;
    readonly resumeToken: string;
    readonly messages: readonly StructuredMessage[];
}
export type PendingResponseState = "enabled" | "submitting" | "awaiting_clear";
export interface PendingInteraction {
    readonly requestId: string;
    readonly kind: string;
    readonly prompt: string;
    readonly responseState?: PendingResponseState;
    readonly options?: readonly string[];
}
export interface SessionState {
    readonly id: string;
    readonly state: string;
    readonly closed: boolean;
}
export type SessionStreamEvent = {
    readonly type: "structured";
    readonly id: string;
    readonly operation: "snapshot" | "reset" | "upsert";
    readonly transcriptStreamId: string;
    readonly resumeToken: string;
    readonly messages: readonly StructuredMessage[];
    readonly resetReason?: StructuredResetReason;
} | {
    readonly type: "pending";
    readonly interaction: PendingInteraction;
} | {
    readonly type: "pending_cleared";
    readonly requestId: string;
} | {
    readonly type: "activity";
    readonly activity: string;
} | {
    readonly type: "heartbeat";
};
export interface SessionStreamRequest {
    readonly sessionId: string;
    readonly afterCursor?: string;
    readonly lastEventId?: string;
    readonly onEvent: (event: SessionStreamEvent) => void;
    readonly onEof: () => void;
    readonly onError: (error: FeedStreamError) => void;
}
export interface FeedStreamError {
    readonly kind: "contract" | "resume_rejected" | "network" | "http" | "unauthorized";
    readonly message: string;
    readonly status?: number;
}
export interface SessionStreamHandle {
    close(): void;
}
export interface FeedPort {
    fetchTranscript(sessionId: string): Promise<TranscriptBootstrap>;
    fetchPending(sessionId: string): Promise<readonly PendingInteraction[]>;
    fetchSession(sessionId: string): Promise<SessionState>;
    openSessionStream(request: SessionStreamRequest): Promise<SessionStreamHandle>;
    respond(sessionId: string, requestId: string, response: Readonly<Record<string, unknown>>): Promise<void>;
}
export interface FeedTranscriptSnapshot {
    readonly transcriptStreamId: string;
    readonly resumeToken: string;
    readonly messages: readonly StructuredMessage[];
}
export interface StructuredFeedSnapshot {
    readonly phase: "idle" | "bootstrapping" | "reconnecting" | "live" | "quiescent" | "failed";
    readonly session: SessionState | null;
    readonly transcript: FeedTranscriptSnapshot | null;
    readonly pending: readonly PendingInteraction[];
    readonly activity: string | null;
    readonly resetNotice: {
        readonly reason: StructuredResetReason;
    } | null;
    readonly issue?: FeedStreamError;
}
export interface StructuredFeedController {
    getSnapshot(): StructuredFeedSnapshot;
    subscribe(listener: () => void): () => void;
    bootstrap(selection: {
        readonly sessionId: string;
    }): Promise<void>;
    reconnect(): Promise<void>;
    respond(requestId: string, response: Readonly<Record<string, unknown>>): Promise<void>;
    dispose(): void;
}
export interface FeedRecoveryPolicy {
    readonly maxContractRebootstraps?: number;
    readonly wait?: (delayMs: number) => Promise<void>;
    readonly jitter?: (maximumMs: number) => number;
}
export declare function createStructuredFeedController(port: FeedPort, recoveryPolicy?: FeedRecoveryPolicy): StructuredFeedController;
export type CityOperationKind = "session.create" | "session.submit";
export interface CityOperationDescriptor {
    readonly requestId: string;
    readonly operation: CityOperationKind;
    readonly eventCursor: string;
}
export interface CityEventFrame {
    readonly id: string;
    readonly eventType: string;
    readonly payload: unknown;
}
export interface CityStreamDisconnect {
    readonly kind: "eof" | "network" | "http" | "contract" | "unregistered";
    readonly status?: number;
    readonly retryAfterMs?: number;
}
export interface CityEventStreamRequest {
    readonly afterSeq?: string;
    readonly lastEventId?: string;
    readonly onEvent: (frame: CityEventFrame) => void;
    readonly onHeartbeat: () => void;
    readonly onDisconnect: (failure: CityStreamDisconnect) => void;
}
export interface CityOperationPort {
    openCityEventStream(request: CityEventStreamRequest): Promise<SessionStreamHandle>;
}
export interface CityOperationSnapshot {
    readonly phase: "idle" | "connecting" | "watching" | "retrying" | "succeeded" | "failed" | "outcome_unknown" | "dismissed";
    readonly cursor: string;
    readonly terminal: CityEventFrame | null;
    readonly unknownReason?: "malformed_terminal" | "unregistered" | "authorization" | "permanent_status" | "retry_exhausted" | "contract" | "watchdog_expired";
}
export interface CityOperationWatcherPolicy {
    readonly wait?: (delayMs: number) => Promise<void>;
    readonly jitter?: (maximumMs: number) => number;
    readonly maxSilentAttempts?: number;
    readonly maxWatchMs?: number;
    readonly armWatchdog?: (onExpire: () => void, timeoutMs: number) => () => void;
}
export interface CityOperationWatcher {
    getSnapshot(): CityOperationSnapshot;
    subscribe(listener: () => void): () => void;
    start(): Promise<void>;
    dismiss(): void;
    dispose(): void;
}
export declare function createCityOperationWatcher(port: CityOperationPort, operation: CityOperationDescriptor, policy?: CityOperationWatcherPolicy): CityOperationWatcher;
//# sourceMappingURL=index.d.ts.map