export interface ConnectionSummary {
    id: string;
    label: string;
    cities: string[];
    available: boolean;
    diagnostic?: string;
}
export interface ConnectionInventory {
    connections: ConnectionSummary[];
}
export interface CitySummary {
    name: string;
    path: string;
    running: boolean;
    status?: string;
    error?: string;
    phases_completed?: string[];
}
export interface CityInventory {
    items: CitySummary[];
    total: number;
}
export interface RigSummary {
    name: string;
    path: string;
    suspended: boolean;
    agent_count: number;
    running_count: number;
}
export interface AgentSummary {
    name: string;
    rig?: string;
    description?: string;
    provider?: string;
    running: boolean;
    suspended: boolean;
    available: boolean;
    state: string;
}
export interface SessionSummary {
    id: string;
    template: string;
    state: string;
    title: string;
    provider: string;
    session_name: string;
    created_at: string;
    running: boolean;
    activity?: string;
    options?: Record<string, string>;
    submission_capabilities?: {
        supports_follow_up: boolean;
        supports_interrupt_now: boolean;
    };
}
export interface ProviderOptionChoice {
    value: string;
    label: string;
}
export interface ProviderOption {
    key: string;
    label: string;
    type: string;
    default: string;
    choices: ProviderOptionChoice[];
}
export interface ProviderPublicSummary {
    name: string;
    display_name?: string;
    builtin: boolean;
    city_level: boolean;
    options_schema?: ProviderOption[];
    effective_defaults?: Record<string, string>;
    compatibility_error?: string;
}
export declare function parseSessionSummary(value: unknown, scope?: string): SessionSummary;
export interface CityTopology {
    rigs: RigSummary[];
    agents: AgentSummary[];
    providers: ProviderPublicSummary[];
    sessions: SessionSummary[];
    sessionTotal: number;
    sessionPartial: boolean;
    sessionPartialErrors: string[];
    nextSessionCursor?: string;
}
export interface SessionPage {
    sessions: SessionSummary[];
    total: number;
    partial: boolean;
    partialErrors: string[];
    nextSessionCursor?: string;
}
export declare function loadSessionPage(connectionId: string, cityName: string, cursor: string, signal: AbortSignal): Promise<SessionPage>;
export declare function loadConnectionInventory(signal: AbortSignal): Promise<ConnectionInventory>;
export declare function loadCities(connectionId: string, signal: AbortSignal): Promise<CityInventory>;
export declare function loadCityTopology(connectionId: string, cityName: string, signal: AbortSignal): Promise<CityTopology>;
//# sourceMappingURL=api.d.ts.map