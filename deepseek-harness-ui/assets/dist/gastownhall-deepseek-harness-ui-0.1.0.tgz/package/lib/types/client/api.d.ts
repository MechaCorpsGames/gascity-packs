export interface ConnectionSummary {
    id: string;
    label: string;
    cities: string[];
    available: boolean;
    diagnostic?: string;
}
export interface ConnectionInventory {
    connections: ConnectionSummary[];
}
export interface CitySummary {
    name: string;
    path: string;
    running: boolean;
    status?: string;
    error?: string;
    phases_completed?: string[];
}
export interface CityInventory {
    items: CitySummary[];
    total: number;
}
export interface RigSummary {
    name: string;
    path: string;
    suspended: boolean;
    agent_count: number;
    running_count: number;
}
export interface AgentSummary {
    name: string;
    rig?: string;
    description?: string;
    provider?: string;
    running: boolean;
    suspended: boolean;
    available: boolean;
    state: string;
}
export interface SessionSummary {
    id: string;
    template: string;
    state: string;
    title: string;
    provider: string;
    session_name: string;
    created_at: string;
    running: boolean;
    activity?: string;
    submission_capabilities?: {
        supports_follow_up: boolean;
        supports_interrupt_now: boolean;
    };
}
export interface CityTopology {
    rigs: RigSummary[];
    agents: AgentSummary[];
    sessions: SessionSummary[];
    nextSessionCursor?: string;
}
export declare function loadConnectionInventory(signal: AbortSignal): Promise<ConnectionInventory>;
export declare function loadCities(connectionId: string, signal: AbortSignal): Promise<CityInventory>;
export declare function loadCityTopology(connectionId: string, cityName: string, signal: AbortSignal): Promise<CityTopology>;
//# sourceMappingURL=api.d.ts.map