import type { FeedPort } from './feed/index.js';
export interface SupervisorFeedPortConfig {
    connectionId: string;
    cityName: string;
    includeThinking: boolean;
    fetch?: typeof globalThis.fetch;
}
export declare function createSupervisorFeedPort(config: SupervisorFeedPortConfig): FeedPort;
//# sourceMappingURL=supervisor-feed-port.d.ts.map