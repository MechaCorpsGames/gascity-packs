import type { Context } from '@deepseek-ai/cordis';
export interface ConnectionSummary {
    id: string;
    label: string;
    cities: string[];
    available: boolean;
    diagnostic?: string;
}
export interface ConnectionInventory {
    connections: ConnectionSummary[];
}
export interface HostBoundary {
    inventory(): Promise<ConnectionInventory>;
    refresh?(): Promise<ConnectionInventory>;
    proxy?(request: GatewayRequest): Promise<Response>;
}
export interface CredentialExecInfo {
    version: 'gascity.dev/client-auth/v1';
    spec: {
        server_url: string;
        city: string;
        interactive: false;
    };
}
export interface CredentialResult {
    token: string;
    expirationTimestamp: string;
}
export interface GrantInfo {
    version: 'gascity.dev/city-write-grant/v1';
    aud: 'gc-city-write';
    city: string;
    method: string;
    path: string;
    canonical_query: string;
    body_sha256: string;
    req_digest: string;
}
export interface ProviderRequest {
    audience: string;
    required_scopes: string[];
    org: string;
    force_refresh: boolean;
}
export interface ProviderCredential {
    accessToken: string;
    authorizationScheme: 'Bearer';
    expiresAt: string;
    audience: string;
    scopes: string[];
}
export interface AuthHelperBoundary {
    credential(command: string, info: CredentialExecInfo): Promise<CredentialResult>;
    grant(command: string, info: GrantInfo): Promise<string>;
    provider(request: ProviderRequest): Promise<ProviderCredential>;
}
export interface GatewayRequest {
    connectionId: string;
    city?: string;
    method: string;
    path: string;
    query: string;
    headers: Record<string, string>;
    body?: string;
}
export interface Config {
    gcHome?: string;
    fetch?: typeof globalThis.fetch;
    helpers?: AuthHelperBoundary;
    /** Test seam and future embedding boundary. Normal profile composition omits it. */
    boundary?: HostBoundary;
}
export declare const inject: string[];
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map