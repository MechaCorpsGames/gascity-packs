import type { AuthHelperBoundary, CredentialExecInfo, CredentialResult, GrantInfo, ProviderCredential, ProviderRequest } from './index.js';
export declare class ProcessAuthHelpers implements AuthHelperBoundary {
    credential(command: string, info: CredentialExecInfo): Promise<CredentialResult>;
    grant(command: string, info: GrantInfo): Promise<string>;
    provider(request: ProviderRequest): Promise<ProviderCredential>;
}
//# sourceMappingURL=helpers.d.ts.map