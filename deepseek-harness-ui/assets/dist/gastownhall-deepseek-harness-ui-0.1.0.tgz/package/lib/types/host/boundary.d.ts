import type { AuthHelperBoundary, HostBoundary } from './index.js';
export interface ProductionBoundaryOptions {
    gcHome?: string;
    fetch?: typeof globalThis.fetch;
    helpers?: AuthHelperBoundary;
}
export declare function createProductionBoundary(options?: ProductionBoundaryOptions): HostBoundary;
//# sourceMappingURL=boundary.d.ts.map