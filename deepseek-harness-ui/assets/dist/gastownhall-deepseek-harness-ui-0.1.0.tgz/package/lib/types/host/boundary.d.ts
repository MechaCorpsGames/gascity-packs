import type { AuthHelperBoundary, HostBoundary } from './index.js';
export declare class GatewayDispatchError extends Error {
    constructor(cause: unknown);
}
export interface ProductionBoundaryOptions {
    gcHome?: string;
    fetch?: typeof globalThis.fetch;
    helpers?: AuthHelperBoundary;
}
export declare function createProductionBoundary(options?: ProductionBoundaryOptions): HostBoundary;
//# sourceMappingURL=boundary.d.ts.map